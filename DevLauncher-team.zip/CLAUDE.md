# CLAUDE.md — Dev Launcher

A tiny Windows desktop app that shows a tile per dev project. Clicking a tile opens
a Windows Terminal tab in that project's folder and starts `claude` with a prompt
telling it to auto-start the app.

## What's here
| File | Role |
|------|------|
| `DevLauncher.exe` | The app. A standalone .NET WinForms exe — **the window belongs to this exe** (this is why it pins to the taskbar correctly). Built from `DevLauncher.cs`. |
| `DevLauncher.cs` | Source for the exe. UI + tile launch logic. |
| `apps.txt` | **Prompt overrides only** (no longer the tile list). Every folder under `C:\Dev` gets a tile automatically; an entry here (matched by path) overrides that tile's display name and initial prompt. Folders without an entry use the folder name + a generic default prompt. |
| `recent.txt` | Auto-written on every launch (`name|ticks` per line). No longer drives startup ordering (tiles sort by folder modified date); a launch still moves its tile to the front for the current session. Safe to delete. |
| `favorites.txt` | Starred folder paths, one per line. Written when a tile's ★ button is toggled. Starred projects show as pills in a favorites bar under the header, ordered by folder modified date. Safe to delete (nothing starred). |
| `DevLauncher.ico` | App icon (blue rounded tile + ⚡). Embedded in the exe and used by the shortcuts. |
| `AppLauncher.ps1` | **Legacy / unused.** The original PowerShell+WPF version. The exe no longer reads it. Kept for reference; safe to delete. |
| `Launch.vbs` | **Legacy / unused.** Old no-flash launcher for the PS1 version. |

Shortcuts pointing at `DevLauncher.exe`:
- Desktop: `Dev Launcher.lnk`
- Start Menu: `%APPDATA%\Microsoft\Windows\Start Menu\Programs\Dev Launcher.lnk`

## How a tile launch works
On click, `Launch()` in `DevLauncher.cs` builds a PowerShell command:
```
$Host.UI.RawUI.WindowTitle = '<name>'; Set-Location -LiteralPath '<path>'; claude '<prompt>'
```
It is **Base64-encoded (UTF-16LE)** and passed as `-EncodedCommand` so quoting/special
chars can never break it. It launches via Windows Terminal:
```
wt.exe -w 0 new-tab --title "<name>" --suppressApplicationTitle -d "<path>" powershell.exe -NoExit -ExecutionPolicy Bypass -EncodedCommand <b64>
```
`--suppressApplicationTitle` locks the tab name so `claude` can't overwrite it.
If `wt.exe` isn't available it falls back to a plain `powershell.exe` window.

## Favorites bar
Each tile has a ★ toggle (top-right, next to the ✎ prompt button). Starring pins the
project as a pill on a favorites bar that appears between the header and the grid;
pills launch on click and are ordered by folder modified date, same as the grid.
Each pill also has its own ✎ button (right edge) that opens the custom-prompt
dialog before launching — same behavior as the tile's ✎ corner button.
Persisted as folder paths in `favorites.txt`; the bar hides when nothing is starred.

## Search + ordering
- The header has a search box (top-right): typing filters tiles by name,
  **Enter launches the top visible match**, **Esc clears**. The ➕ New Project tile
  hides while a search is active.
- **Tiles = all folders under `C:\Dev`**, ordered by folder `LastWriteTime`
  (most recently modified first). Hidden folders are skipped. `LoadApps()` scans
  the folder on startup — no list to maintain. Every `Launch()` still stamps
  `recent.txt` and moves its tile to the front for the current session. Tiles
  carry their `AppEntry` in `Control.Tag`; the filter keys off that.

## Customizing a tile's prompt
Edit `apps.txt` (overrides only — folders show up without an entry). One entry per
line, `#` lines are comments:
```
Name | C:\Path\To\Folder | What Claude should do first (the initial prompt)
```
Matched to a folder by path. Reopen the launcher to pick up changes. Keep `|` out
of the prompt text (it's the delimiter). An apps.txt entry pointing outside
`C:\Dev` still gets a tile (appended after the scanned folders).

## Rebuilding the exe (only when DevLauncher.cs changes)
```powershell
$csc = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
Get-Process DevLauncher -ErrorAction SilentlyContinue | Stop-Process -Force   # release the file first
& $csc /nologo /target:winexe /out:DevLauncher.exe /win32icon:DevLauncher.ico `
    /r:System.Windows.Forms.dll /r:System.Drawing.dll DevLauncher.cs
```
Build target is .NET Framework `csc` (always present on Windows). `winexe` = no console window.

## Gotchas / hard-won notes
- **Taskbar pinning must be the exe, not a PowerShell host.** Earlier versions launched
  PowerShell and the pin captured PowerShell instead. The exe owns its own window now —
  don't reintroduce a "launch powershell then exit" stub.
- **Windows 11 (24H2) blocks programmatic pinning** of both taskbar AND Start (`Access denied`).
  Pinning is a manual right-click → Pin to taskbar. Don't waste time scripting it.
- **Pasted prompts need TWO escaping layers — both were once missing.** A prompt pasted from
  Outlook/Word hits two distinct Windows quoting traps; `Launch()` now handles both (see the
  helpers above it). Verified end-to-end against the real `claude.exe`.
  1. *Curly "smart" quotes (PowerShell layer).* PowerShell treats the Unicode curly single-quotes
     (U+2018/2019/201A/201B) as string delimiters too — not just ASCII `'`. A curly apostrophe
     ("I've", "don't") closed the `claude -- '...'` string early and the rest got parsed as
     PowerShell code (`ampersand not allowed` / `missing terminator`). `NormalizeQuotes()` maps the
     curly singles to ASCII `'` BEFORE doubling. Used for name/path/prompt.
  2. *Double-quote stripping (native-arg layer).* Windows PowerShell 5.1 wraps a native-command arg
     with spaces in `"..."` but does NOT escape the arg's own `"`, so a JSON/quoted prompt loses its
     quotes and then word-splits on the now-unquoted spaces — `claude` receives only the first chunk
     and the prompt looks "cut off" (e.g. `{ objection: Already`). `WinArgInner()` applies the
     standard `CommandLineToArgvW` escaping (`"` -> `\"`, backslash-run doubling). Only the **prompt**
     needs this (it's the only field passed to `claude.exe` as an argv element); name/path are
     consumed by PowerShell itself. So: prompt = `PsPromptArg` (both layers), name/path =
     `PsSingleQuote` (curly + `'`->`''` only). Don't collapse these back to a bare
     `.Replace("'", "''")`.
- The icon is generated with `System.Drawing`; `DrawString` needs a `RectangleF`, not a `Rectangle`.
- XAML in the old PS version needed `xmlns:x` declared or `x:Name` fails to parse (legacy file only).
