using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

// Standalone Dev Launcher. The window belongs to THIS exe (not powershell),
// so it pins to the taskbar as "Dev Launcher" and relaunches correctly.
// Tiles are read from apps.txt next to the exe -> no recompile to edit them.

class AppEntry { public string Name = "", Path = "", Prompt = ""; public DateTime Modified; }

static class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new LauncherForm());
    }
}

class LauncherForm : Form
{
    static readonly Color[] Palette = {
        ColorTranslator.FromHtml("#2563EB"), ColorTranslator.FromHtml("#0891B2"),
        ColorTranslator.FromHtml("#7C3AED"), ColorTranslator.FromHtml("#DB2777"),
        ColorTranslator.FromHtml("#059669"), ColorTranslator.FromHtml("#D97706"),
        ColorTranslator.FromHtml("#DC2626"), ColorTranslator.FromHtml("#4F46E5"),
        ColorTranslator.FromHtml("#0D9488"), ColorTranslator.FromHtml("#C026D3"),
    };

    // Where new projects are created, and the default prompt new tiles get.
    const string ProjectsRoot = @"C:\Dev";
    const string NewProjectPrompt =
        "Read CLAUDE.md and the latest file in sessions/ to catch up on history, then continue work. "
        + "Track this session in sessions/ per the rules in CLAUDE.md, updating it after every turn.";

    FlowLayoutPanel flow;   // tile area, so new tiles can be appended after creation
    int colorIndex;         // next palette color to hand out
    Label emptyHint;        // "no apps" placeholder, removed once a tile exists
    readonly ToolTip tip = new ToolTip();  // shared tooltip for tile buttons
    TextBox searchBox;      // header filter; tiles hide/show as you type
    Control newProjectTile; // kept last; hidden while a search is active
    Dictionary<string, DateTime> lastUsed;  // app name -> last launch (recent.txt)
    FlowLayoutPanel favBar; // starred-projects strip under the header
    HashSet<string> favorites;  // starred folder paths (favorites.txt)
    List<AppEntry> allApps;     // every tile's entry, sorted by Modified desc

    public LauncherForm()
    {
        Text = "Dev Launcher";
        BackColor = ColorTranslator.FromHtml("#0F172A");
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(720, 560);
        MinimumSize = new Size(360, 300);
        try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

        // header
        // Width must be set BEFORE anchored children are added: Anchor=Right captures
        // the distance to the parent's right edge at add time, and a docked panel
        // still has the 200px default width until it's added to the form.
        var header = new Panel { Dock = DockStyle.Top, Height = 70, Width = ClientSize.Width,
            BackColor = ColorTranslator.FromHtml("#111C32") };
        var title = new Label {
            Text = "Dev Launcher", ForeColor = ColorTranslator.FromHtml("#F8FAFC"),
            Font = new Font("Segoe UI", 15F, FontStyle.Bold), AutoSize = true,
            Location = new Point(20, 12), BackColor = Color.Transparent };
        var sub = new Label {
            Text = "Click an app — opens a terminal in the folder and starts Claude on it.",
            ForeColor = ColorTranslator.FromHtml("#94A3B8"), Font = new Font("Segoe UI", 9F),
            AutoSize = true, Location = new Point(22, 42), BackColor = Color.Transparent };
        header.Controls.Add(sub);
        header.Controls.Add(title);

        // Search box: filters tiles by name as you type. Enter launches the
        // first (= most recently used) match; Esc clears.
        searchBox = new TextBox {
            Location = new Point(ClientSize.Width - 236, 22), Size = new Size(220, 24),
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
            BackColor = ColorTranslator.FromHtml("#1E293B"),
            ForeColor = ColorTranslator.FromHtml("#F8FAFC"),
            BorderStyle = BorderStyle.FixedSingle, Font = new Font("Segoe UI", 10F) };
        searchBox.TextChanged += (s, e) => ApplyFilter();
        searchBox.KeyDown += (s, e) => {
            if (e.KeyCode == Keys.Enter)  { LaunchFirstVisible(); e.SuppressKeyPress = true; }
            if (e.KeyCode == Keys.Escape) { searchBox.Text = "";  e.SuppressKeyPress = true; }
        };
        searchBox.HandleCreated += (s, e) =>
            SendMessage(searchBox.Handle, EM_SETCUEBANNER, (IntPtr)1, "Search apps…");
        header.Controls.Add(searchBox);

        // favorites bar: pill per starred project, newest-modified first.
        // Hidden until something is starred. AutoSize so pills can wrap to a
        // second row without clipping.
        favBar = new FlowLayoutPanel {
            Dock = DockStyle.Top, AutoSize = true, WrapContents = true,
            Padding = new Padding(10, 6, 10, 2), Visible = false,
            BackColor = ColorTranslator.FromHtml("#0B1222") };

        // tile area
        flow = new FlowLayoutPanel {
            Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(10),
            BackColor = ColorTranslator.FromHtml("#0F172A") };

        // Dock order is reverse of add order: header docks Top first,
        // then favBar docks Top beneath it, then flow fills the rest.
        Controls.Add(flow);
        Controls.Add(favBar);
        Controls.Add(header);

        // Focus the search box on open so you can just start typing.
        ActiveControl = searchBox;
        Shown += (s, e) => searchBox.Focus();

        lastUsed = LoadRecent();
        favorites = LoadFavorites();
        // Tiles come pre-sorted by folder modified date (newest first).
        var apps = LoadApps();
        allApps = apps;
        foreach (var app in apps)
            flow.Controls.Add(MakeTile(app, Palette[colorIndex++ % Palette.Length]));

        // "New Project" tile always lives last so it's easy to find.
        newProjectTile = MakeNewProjectTile();
        flow.Controls.Add(newProjectTile);

        RebuildFavBar();

        if (apps.Count == 0)
        {
            emptyHint = new Label {
                Text = "No apps yet. Click ➕ New Project to create one,\nor edit apps.txt next to the launcher.",
                ForeColor = ColorTranslator.FromHtml("#94A3B8"), AutoSize = true,
                Margin = new Padding(12) };
            flow.Controls.Add(emptyHint);
        }
    }

    Control MakeTile(AppEntry app, Color color)
    {
        var tile = new Panel {
            Width = 200, Height = 96, Margin = new Padding(8),
            BackColor = color, Cursor = Cursors.Hand, Tag = app };
        RoundCorners(tile, 14);

        var name = new Label {
            Text = app.Name, ForeColor = Color.White,
            Font = new Font("Segoe UI", 13F, FontStyle.Bold), AutoSize = false,
            Location = new Point(14, 16), Size = new Size(108, 26),
            BackColor = Color.Transparent, Cursor = Cursors.Hand };
        var path = new Label {
            Text = app.Path, ForeColor = Color.FromArgb(230, 255, 255, 255),
            Font = new Font("Segoe UI", 8F), AutoEllipsis = true, AutoSize = false,
            Location = new Point(14, 48), Size = new Size(172, 34),
            BackColor = Color.Transparent, Cursor = Cursors.Hand };

        // Small corner button: launch this project with a custom one-off prompt.
        var promptBtn = new Label {
            Text = "✎", ForeColor = Color.White,
            Font = new Font("Segoe UI", 11F, FontStyle.Bold), AutoSize = false,
            TextAlign = ContentAlignment.MiddleCenter, Size = new Size(28, 24),
            Location = new Point(160, 8), BackColor = Color.FromArgb(48, 255, 255, 255),
            Cursor = Cursors.Hand };
        RoundCorners(promptBtn, 7);
        tip.SetToolTip(promptBtn, "Launch with a custom prompt…");
        promptBtn.Click += (s, e) => LaunchWithPrompt(app);
        Color btnBase = promptBtn.BackColor, btnHover = Color.FromArgb(110, 255, 255, 255);
        promptBtn.MouseEnter += (s, e) => promptBtn.BackColor = btnHover;
        promptBtn.MouseLeave += (s, e) => promptBtn.BackColor = btnBase;

        // Star toggle: pins/unpins this project on the favorites bar.
        var starBtn = new Label {
            Text = IsFavorite(app) ? "★" : "☆",
            ForeColor = IsFavorite(app) ? ColorTranslator.FromHtml("#FBBF24") : Color.White,
            Font = new Font("Segoe UI", 11F, FontStyle.Bold), AutoSize = false,
            TextAlign = ContentAlignment.MiddleCenter, Size = new Size(28, 24),
            Location = new Point(126, 8), BackColor = Color.FromArgb(48, 255, 255, 255),
            Cursor = Cursors.Hand };
        RoundCorners(starBtn, 7);
        tip.SetToolTip(starBtn, "Star: pin to the favorites bar");
        starBtn.Click += (s, e) => {
            ToggleFavorite(app);
            starBtn.Text = IsFavorite(app) ? "★" : "☆";
            starBtn.ForeColor = IsFavorite(app)
                ? ColorTranslator.FromHtml("#FBBF24") : Color.White;
        };
        starBtn.MouseEnter += (s, e) => starBtn.BackColor = btnHover;
        starBtn.MouseLeave += (s, e) => starBtn.BackColor = btnBase;

        EventHandler click = (s, e) => Launch(app);
        tile.Click += click; name.Click += click; path.Click += click;

        // simple hover feedback
        Color baseC = color, hoverC = ControlPaint.Light(color, 0.15f);
        EventHandler enter = (s, e) => tile.BackColor = hoverC;
        EventHandler leave = (s, e) => tile.BackColor = baseC;
        tile.MouseEnter += enter; tile.MouseLeave += leave;
        name.MouseEnter += enter; path.MouseEnter += enter;

        tile.Controls.Add(name);
        tile.Controls.Add(path);
        tile.Controls.Add(promptBtn);   // corner buttons added last -> sit on top
        tile.Controls.Add(starBtn);
        return tile;
    }

    // ---- favorites, persisted in favorites.txt next to the exe ----

    static string FavoritesFile()
    {
        return Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "favorites.txt");
    }

    static HashSet<string> LoadFavorites()
    {
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        try
        {
            string file = FavoritesFile();
            if (!File.Exists(file)) return set;
            foreach (var line in File.ReadAllLines(file))
            {
                var p = line.Trim();
                if (p.Length > 0) set.Add(p);
            }
        }
        catch { }   // a broken favorites.txt must never block startup
        return set;
    }

    void SaveFavorites()
    {
        try { File.WriteAllLines(FavoritesFile(), favorites.ToArray()); }
        catch { }   // favorites are a nicety; never crash over them
    }

    bool IsFavorite(AppEntry app) { return favorites.Contains(app.Path); }

    void ToggleFavorite(AppEntry app)
    {
        if (!favorites.Remove(app.Path)) favorites.Add(app.Path);
        SaveFavorites();
        RebuildFavBar();
    }

    // Repopulate the favorites strip: one pill per starred project,
    // ordered by folder modified date (newest first), same as the grid.
    void RebuildFavBar()
    {
        favBar.SuspendLayout();
        favBar.Controls.Clear();
        var favs = allApps.Where(IsFavorite)
                          .OrderByDescending(a => a.Modified).ToList();
        foreach (var app in favs) favBar.Controls.Add(MakePill(app));
        favBar.Visible = favs.Count > 0;
        favBar.ResumeLayout();
    }

    // Compact click-to-launch pill for the favorites bar. The ✎ on the right
    // launches with a one-off custom prompt, same as the tile corner button.
    Control MakePill(AppEntry app)
    {
        var font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
        string text = "★ " + app.Name;
        int textW = TextRenderer.MeasureText(text, font).Width + 14;
        var pill = new Panel {
            Size = new Size(textW + 28, 30), Margin = new Padding(4),
            BackColor = ColorTranslator.FromHtml("#1E293B"),
            Cursor = Cursors.Hand, Tag = app };
        RoundCorners(pill, 15);

        var label = new Label {
            Text = text, Font = font, AutoSize = false,
            TextAlign = ContentAlignment.MiddleCenter,
            Location = new Point(0, 0), Size = new Size(textW, 30),
            ForeColor = ColorTranslator.FromHtml("#FBBF24"),
            BackColor = Color.Transparent, Cursor = Cursors.Hand };
        tip.SetToolTip(label, app.Path);

        var promptBtn = new Label {
            Text = "✎", ForeColor = ColorTranslator.FromHtml("#E2E8F0"),
            Font = new Font("Segoe UI", 9F, FontStyle.Bold), AutoSize = false,
            TextAlign = ContentAlignment.MiddleCenter, Size = new Size(22, 22),
            Location = new Point(textW, 4),
            BackColor = Color.FromArgb(40, 255, 255, 255), Cursor = Cursors.Hand };
        RoundCorners(promptBtn, 7);
        tip.SetToolTip(promptBtn, "Launch with a custom prompt…");
        promptBtn.Click += (s, e) => LaunchWithPrompt(app);
        Color btnBase = promptBtn.BackColor, btnHover = Color.FromArgb(110, 255, 255, 255);
        promptBtn.MouseEnter += (s, e) => promptBtn.BackColor = btnHover;
        promptBtn.MouseLeave += (s, e) => promptBtn.BackColor = btnBase;

        EventHandler click = (s, e) => Launch(app);
        pill.Click += click; label.Click += click;

        Color baseC = pill.BackColor, hoverC = ControlPaint.Light(baseC, 0.35f);
        EventHandler enter = (s, e) => pill.BackColor = hoverC;
        EventHandler leave = (s, e) => pill.BackColor = baseC;
        pill.MouseEnter += enter; pill.MouseLeave += leave;
        label.MouseEnter += enter;

        pill.Controls.Add(label);
        pill.Controls.Add(promptBtn);
        return pill;
    }

    // A distinct dashed-look tile that creates a brand-new project.
    Control MakeNewProjectTile()
    {
        var tile = new Panel {
            Width = 200, Height = 96, Margin = new Padding(8),
            BackColor = ColorTranslator.FromHtml("#1E293B"), Cursor = Cursors.Hand };
        RoundCorners(tile, 14);

        var label = new Label {
            Text = "➕  New Project", ForeColor = ColorTranslator.FromHtml("#E2E8F0"),
            Font = new Font("Segoe UI", 12F, FontStyle.Bold), AutoSize = false,
            TextAlign = ContentAlignment.MiddleCenter, Dock = DockStyle.Fill,
            BackColor = Color.Transparent, Cursor = Cursors.Hand };

        EventHandler click = (s, e) => CreateNewProject();
        tile.Click += click; label.Click += click;

        Color baseC = tile.BackColor, hoverC = ControlPaint.Light(baseC, 0.25f);
        EventHandler enter = (s, e) => tile.BackColor = hoverC;
        EventHandler leave = (s, e) => tile.BackColor = baseC;
        tile.MouseEnter += enter; tile.MouseLeave += leave;
        label.MouseEnter += enter;

        tile.Controls.Add(label);
        return tile;
    }

    // Prompt for a name, scaffold C:\Dev\<name> with CLAUDE.md + sessions\,
    // persist it to apps.txt, add a live tile, and offer to open it.
    void CreateNewProject()
    {
        string name = PromptForName();
        if (name == null) return;                 // cancelled
        name = name.Trim();
        if (name.Length == 0) return;

        // Reject characters that aren't valid in a Windows folder name.
        if (name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
        {
            MessageBox.Show("That name has characters Windows doesn't allow in a folder.",
                "Invalid name", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        string projectPath = Path.Combine(ProjectsRoot, name);
        if (Directory.Exists(projectPath))
        {
            MessageBox.Show("A folder already exists at:\n" + projectPath,
                "Already exists", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        try
        {
            Directory.CreateDirectory(projectPath);
            Directory.CreateDirectory(Path.Combine(projectPath, "sessions"));
            File.WriteAllText(Path.Combine(projectPath, "CLAUDE.md"), ClaudeMdFor(name));
            File.WriteAllText(Path.Combine(projectPath, "sessions", ".gitkeep"), "");
            AppendToAppsTxt(name, projectPath, NewProjectPrompt);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Couldn't create the project:\n" + ex.Message,
                "Create error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        // Add a live tile (insert before the New Project tile, which stays last).
        var app = new AppEntry { Name = name, Path = projectPath, Prompt = NewProjectPrompt,
            Modified = DateTime.Now };
        allApps.Insert(0, app);   // newest-modified, so starring it works immediately
        if (emptyHint != null) { flow.Controls.Remove(emptyHint); emptyHint = null; }
        var newTile = MakeTile(app, Palette[colorIndex++ % Palette.Length]);
        flow.Controls.Add(newTile);
        flow.Controls.SetChildIndex(newTile, flow.Controls.Count - 2); // keep "New Project" last

        if (MessageBox.Show("Created " + name + " at:\n" + projectPath
                + "\n\nOpen it in a terminal with Claude now?",
                "Project created", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
            == DialogResult.Yes)
            Launch(app);
    }

    // The starter CLAUDE.md, with the session-tracking rules the user asked for.
    static string ClaudeMdFor(string name)
    {
        return
"# CLAUDE.md — " + name + "\n" +
"\n" +
"New project scaffolded by Dev Launcher.\n" +
"\n" +
"## Session tracking (required)\n" +
"Every working session MUST be tracked in the `sessions/` folder so progress survives a\n" +
"shutdown or crash and there is a durable historical record of how this project evolved.\n" +
"\n" +
"Rules:\n" +
"- At the **start** of a session, create a new file `sessions/SESSION-<YYYY-MM-DD>-<NN>.md`\n" +
"  (NN = the next number for that day). Begin it with the date/time, the goal of the\n" +
"  session, and a one-line summary of where the project currently stands.\n" +
"- **After every turn**, append what just happened: what was attempted, what changed\n" +
"  (files, commands run, decisions made), the result, and the next intended step. Write\n" +
"  this incrementally as you go — never batch it to the end — so an unexpected shutdown\n" +
"  loses nothing.\n" +
"- At the **start** of any later session, read the most recent file in `sessions/` (and\n" +
"  skim earlier ones as needed) to restore context before doing any work.\n" +
"- Treat `sessions/` as append-only history: start a new file per session, don't rewrite\n" +
"  or delete past session logs.\n" +
"\n" +
"## What this project is\n" +
"_(Fill this in as the project takes shape.)_\n";
    }

    // Persist the new tile to apps.txt so it survives a relaunch.
    static void AppendToAppsTxt(string name, string path, string prompt)
    {
        string dir = Path.GetDirectoryName(Application.ExecutablePath);
        string file = Path.Combine(dir, "apps.txt");
        string line = name + " | " + path + " | " + prompt + Environment.NewLine;
        File.AppendAllText(file, line);
    }

    // Minimal modal text-input dialog (WinForms has no built-in InputBox).
    static string PromptForName()
    {
        using (var dlg = new Form())
        {
            dlg.Text = "New Project";
            dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
            dlg.StartPosition = FormStartPosition.CenterParent;
            dlg.ClientSize = new Size(380, 130);
            dlg.MaximizeBox = false; dlg.MinimizeBox = false;
            dlg.BackColor = ColorTranslator.FromHtml("#0F172A");

            var prompt = new Label {
                Text = "Project name (a folder is created under " + ProjectsRoot + "):",
                ForeColor = ColorTranslator.FromHtml("#E2E8F0"), AutoSize = false,
                Location = new Point(16, 14), Size = new Size(348, 36) };
            var box = new TextBox {
                Location = new Point(16, 52), Size = new Size(348, 24) };
            var ok = new Button {
                Text = "Create", DialogResult = DialogResult.OK,
                Location = new Point(196, 90), Size = new Size(80, 28) };
            var cancel = new Button {
                Text = "Cancel", DialogResult = DialogResult.Cancel,
                Location = new Point(284, 90), Size = new Size(80, 28) };

            dlg.Controls.Add(prompt);
            dlg.Controls.Add(box);
            dlg.Controls.Add(ok);
            dlg.Controls.Add(cancel);
            dlg.AcceptButton = ok;
            dlg.CancelButton = cancel;

            return dlg.ShowDialog() == DialogResult.OK ? box.Text : null;
        }
    }

    static void RoundCorners(Control c, int radius)
    {
        var gp = new GraphicsPath();
        int d = radius * 2;
        gp.AddArc(0, 0, d, d, 180, 90);
        gp.AddArc(c.Width - d, 0, d, d, 270, 90);
        gp.AddArc(c.Width - d, c.Height - d, d, d, 0, 90);
        gp.AddArc(0, c.Height - d, d, d, 90, 90);
        gp.CloseFigure();
        c.Region = new Region(gp);
    }

    // Prompt used for folders that have no apps.txt entry.
    const string DefaultPrompt =
        "Read CLAUDE.md and/or the README if present to understand this project, "
        + "then help me continue working on it.";

    // Every folder directly under C:\Dev gets a tile, ordered by folder modified
    // date (newest first). apps.txt is an OVERRIDES file: an entry whose path
    // matches a folder supplies its display name and initial prompt; folders
    // without an entry get the folder name and DefaultPrompt.
    List<AppEntry> LoadApps()
    {
        var overrides = LoadAppsTxt();
        var list = new List<AppEntry>();
        try
        {
            foreach (var d in new DirectoryInfo(ProjectsRoot).GetDirectories()
                         .Where(d => (d.Attributes & FileAttributes.Hidden) == 0)
                         .OrderByDescending(d => d.LastWriteTime))
            {
                AppEntry o;
                overrides.TryGetValue(d.FullName, out o);
                list.Add(new AppEntry {
                    Name   = (o != null && o.Name.Length   > 0) ? o.Name   : d.Name,
                    Path   = d.FullName,
                    Prompt = (o != null && o.Prompt.Length > 0) ? o.Prompt : DefaultPrompt,
                    Modified = d.LastWriteTime
                });
            }
        }
        catch { }   // an unreadable ProjectsRoot must never block startup

        // apps.txt entries pointing somewhere else (outside C:\Dev) still get tiles.
        foreach (var o in overrides.Values)
            if (!list.Any(a => a.Path.Equals(o.Path, StringComparison.OrdinalIgnoreCase)))
            {
                try { o.Modified = Directory.GetLastWriteTime(o.Path); } catch { }
                list.Add(o);
            }
        return list;
    }

    // apps.txt entries keyed by normalized full path (case-insensitive).
    static Dictionary<string, AppEntry> LoadAppsTxt()
    {
        var map = new Dictionary<string, AppEntry>(StringComparer.OrdinalIgnoreCase);
        string dir = Path.GetDirectoryName(Application.ExecutablePath);
        string file = Path.Combine(dir, "apps.txt");
        if (!File.Exists(file)) return map;

        foreach (var raw in File.ReadAllLines(file))
        {
            var line = raw.Trim();
            if (line.Length == 0 || line.StartsWith("#")) continue;
            var parts = line.Split(new[] { '|' }, 3);
            if (parts.Length < 2) continue;
            var entry = new AppEntry {
                Name = parts[0].Trim(),
                Path = parts[1].Trim(),
                Prompt = parts.Length >= 3 ? parts[2].Trim() : ""
            };
            string key;
            try { key = Path.GetFullPath(entry.Path).TrimEnd('\\'); }
            catch { continue; }   // skip malformed paths rather than crash
            map[key] = entry;
        }
        return map;
    }

    // ---- search ----

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);
    const int EM_SETCUEBANNER = 0x1501;   // native textbox placeholder text

    // Show only tiles whose name contains the query. App tiles carry their
    // AppEntry in Tag; the New Project tile (Tag == null) hides during a search.
    void ApplyFilter()
    {
        string q = searchBox.Text.Trim();
        flow.SuspendLayout();
        foreach (Control c in flow.Controls)
        {
            var app = c.Tag as AppEntry;
            if (app != null)
                c.Visible = q.Length == 0
                    || app.Name.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0;
            else if (c == newProjectTile)
                c.Visible = q.Length == 0;
        }
        flow.ResumeLayout();
    }

    // Enter in the search box: launch the top visible tile (MRU order = best match first-ish).
    void LaunchFirstVisible()
    {
        foreach (Control c in flow.Controls)
        {
            var app = c.Tag as AppEntry;
            if (app != null && c.Visible) { Launch(app); return; }
        }
    }

    // ---- most-recently-used ordering, persisted in recent.txt next to the exe ----

    static string RecentFile()
    {
        return Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "recent.txt");
    }

    DateTime GetLastUsed(string name)
    {
        DateTime t;
        return lastUsed.TryGetValue(name, out t) ? t : DateTime.MinValue;
    }

    static Dictionary<string, DateTime> LoadRecent()
    {
        var map = new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);
        try
        {
            string file = RecentFile();
            if (!File.Exists(file)) return map;
            foreach (var line in File.ReadAllLines(file))
            {
                int bar = line.LastIndexOf('|');   // name can't contain | (apps.txt rule)
                if (bar <= 0) continue;
                long ticks;
                if (long.TryParse(line.Substring(bar + 1).Trim(), out ticks))
                    map[line.Substring(0, bar).Trim()] = new DateTime(ticks);
            }
        }
        catch { }   // a broken recent.txt must never block startup
        return map;
    }

    // Stamp the launch time, persist it, and move the tile to the front
    // so the MRU order is visible immediately (not just on next open).
    void RecordUsage(string name)
    {
        lastUsed[name] = DateTime.Now;
        try
        {
            var sb = new StringBuilder();
            foreach (var kv in lastUsed)
                sb.Append(kv.Key).Append('|').Append(kv.Value.Ticks).Append(Environment.NewLine);
            File.WriteAllText(RecentFile(), sb.ToString());
        }
        catch { }   // ordering is a nicety; never fail a launch over it

        foreach (Control c in flow.Controls)
        {
            var app = c.Tag as AppEntry;
            if (app != null && app.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
            { flow.Controls.SetChildIndex(c, 0); break; }
        }
    }

    // Pop a clean textbox to paste/type a one-off prompt, then launch with it.
    void LaunchWithPrompt(AppEntry app)
    {
        string prompt = PromptForLaunchText(app.Name);
        if (prompt == null) return;                 // cancelled
        prompt = prompt.Trim();
        if (prompt.Length == 0) return;             // nothing to send
        var oneOff = new AppEntry { Name = app.Name, Path = app.Path, Prompt = prompt };
        Launch(oneOff);
    }

    // Modal multiline input for a custom launch prompt. Returns null if cancelled.
    static string PromptForLaunchText(string appName)
    {
        using (var dlg = new Form())
        {
            dlg.Text = "Launch " + appName + " with a prompt";
            dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
            dlg.StartPosition = FormStartPosition.CenterParent;
            dlg.ClientSize = new Size(460, 280);
            dlg.MaximizeBox = false; dlg.MinimizeBox = false;
            dlg.BackColor = ColorTranslator.FromHtml("#0F172A");

            var label = new Label {
                Text = "Prompt to start this session with (paste or type, then Start):",
                ForeColor = ColorTranslator.FromHtml("#E2E8F0"), AutoSize = false,
                Location = new Point(16, 12), Size = new Size(428, 22) };
            var box = new TextBox {
                Location = new Point(16, 40), Size = new Size(428, 190),
                Multiline = true, AcceptsReturn = true, WordWrap = true,
                ScrollBars = ScrollBars.Vertical, Font = new Font("Segoe UI", 10F) };
            var start = new Button {
                Text = "Start", DialogResult = DialogResult.OK,
                Location = new Point(276, 240), Size = new Size(80, 28) };
            var cancel = new Button {
                Text = "Cancel", DialogResult = DialogResult.Cancel,
                Location = new Point(364, 240), Size = new Size(80, 28) };

            dlg.Controls.Add(label);
            dlg.Controls.Add(box);
            dlg.Controls.Add(start);
            dlg.Controls.Add(cancel);
            // Enter inside the box makes a newline (multiline); Start is clicked explicitly.
            dlg.CancelButton = cancel;

            return dlg.ShowDialog() == DialogResult.OK ? box.Text : null;
        }
    }

    // Normalize the curly "smart" single-quotes (U+2018/2019/201A/201B) to ASCII '.
    // PowerShell treats the curly variants as string delimiters too, NOT just ASCII ',
    // so a prompt pasted from Outlook/Word (e.g. "I've", "don't") would otherwise close
    // the surrounding PowerShell single-quoted string early.
    static string NormalizeQuotes(string s)
    {
        const char SQ = '\'';
        return s.Replace((char)0x2018, SQ).Replace((char)0x2019, SQ)
                .Replace((char)0x201A, SQ).Replace((char)0x201B, SQ);
    }

    // Escape a string for embedding inside a PowerShell single-quoted literal: ' -> ''.
    // Used for fields consumed by PowerShell itself (tab title, Set-Location path).
    static string PsSingleQuote(string s)
    {
        if (s == null) return "";
        return NormalizeQuotes(s).Replace("'", "''");
    }

    // Escape a string so it survives as ONE argv element through claude.exe's native
    // CommandLineToArgvW parsing. Windows PowerShell 5.1 wraps a native-command arg that
    // contains spaces in double quotes but does NOT escape the arg's own double quotes —
    // so a JSON/quoted prompt loses its " and then word-splits on the now-unquoted spaces,
    // and claude only receives the first chunk (the prompt looks "cut off"). Per the
    // standard argv rules: double any backslash run that precedes a ", escape each " as \",
    // and double a trailing backslash run (it would precede PowerShell's closing wrap ").
    static string WinArgInner(string s)
    {
        var sb = new StringBuilder();
        int slashes = 0;
        foreach (char c in s)
        {
            if (c == '\\') { slashes++; continue; }
            if (c == '"') { sb.Append('\\', slashes * 2 + 1).Append('"'); slashes = 0; continue; }
            if (slashes > 0) { sb.Append('\\', slashes); slashes = 0; }
            sb.Append(c);
        }
        if (slashes > 0) sb.Append('\\', slashes * 2);
        return sb.ToString();
    }

    // The prompt is the ONLY field passed to claude.exe as a native argument, so it needs
    // BOTH layers: native-arg escaping (for claude.exe) then single-quote escaping (for the
    // PowerShell -EncodedCommand script that wraps it).
    static string PsPromptArg(string s)
    {
        if (s == null) return "";
        return WinArgInner(NormalizeQuotes(s)).Replace("'", "''");
    }

    void Launch(AppEntry a)
    {
        RecordUsage(a.Name);

        // PowerShell command the new tab runs: name the tab, cd in, start claude.
        string name = PsSingleQuote(a.Name);
        string path = PsSingleQuote(a.Path);
        string prompt = PsPromptArg(a.Prompt);
        // `--` ends claude's option parsing so a prompt that starts with '-'
        // (e.g. a pasted markdown bullet) is taken as the prompt, not a flag.
        string inner = "$Host.UI.RawUI.WindowTitle = '" + name + "'; "
                     + "Set-Location -LiteralPath '" + path + "'; "
                     + "claude -- '" + prompt + "'";
        string enc = Convert.ToBase64String(Encoding.Unicode.GetBytes(inner));

        // Prefer Windows Terminal (named, suppressed-title tab); fall back to PowerShell.
        try
        {
            var psi = new ProcessStartInfo("wt.exe",
                "-w 0 new-tab --title \"" + a.Name + "\" --suppressApplicationTitle "
                + "-d \"" + a.Path + "\" "
                + "powershell.exe -NoExit -ExecutionPolicy Bypass -EncodedCommand " + enc)
            { UseShellExecute = true };
            Process.Start(psi);
        }
        catch
        {
            try
            {
                var psi = new ProcessStartInfo("powershell.exe",
                    "-NoExit -ExecutionPolicy Bypass -EncodedCommand " + enc)
                { UseShellExecute = true };
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Couldn't launch " + a.Name + ":\n" + ex.Message, "Launch error");
            }
        }
    }
}
