# Dev Launcher — Machine Setup

**These are instructions for Claude Code.** The user just unzipped Dev Launcher and
wants it installed on this machine: built, working, with a desktop shortcut, and
ready to pin. Work through the steps in order.

Dev Launcher is a tiny Windows WinForms app that shows a tile for every project
folder under a single "projects root" folder. Clicking a tile opens a Windows
Terminal tab in that folder and starts `claude` with an initial prompt.
`CLAUDE.md` in this folder documents the internals; you don't need it for setup,
but read it before changing any code.

## Step 0 — Confirm where the files live

The folder containing this SETUP.md is the launcher's permanent home — the exe,
its shortcuts, and its data files (`apps.txt`, `favorites.txt`, `recent.txt`) all
live here. If the user unzipped it somewhere temporary (Downloads, Desktop), ask
them where they'd like it to live (e.g. `C:\Dev\launcher`) and move the folder
there first. Everything below uses full paths to this folder.

## Step 1 — Ask the user for their projects root (REQUIRED, do this first)

**Ask the user which folder they want to use as their projects root** — the
folder whose subfolders become tiles. Do not assume `C:\Dev`; ask. A good way to
phrase it: "Which folder holds your dev projects? Every subfolder of it will get
a tile in the launcher (e.g. `C:\Dev`, `C:\Code`, `C:\repos`)."

- If the folder they name doesn't exist, confirm and create it.
- Hidden subfolders are skipped automatically; empty root just shows the
  ➕ New Project tile, which is fine.

## Step 2 — Point the app at that root

In `DevLauncher.cs`, near the top of the class, there is a single constant:

```csharp
const string ProjectsRoot = @"C:\Dev";
```

Change it to the user's chosen root. That constant is the only machine-specific
value in the source — everything else (apps.txt, favorites, recents) resolves
relative to the exe.

If the chosen root is not `C:\Dev`, also do a quick find/replace of `C:\Dev` in
the comment headers of `apps.txt` and in `CLAUDE.md` so the docs stay accurate
on this machine.

## Step 3 — Build the exe

Build with the .NET Framework compiler (present on every Windows machine — do
NOT reach for `dotnet build`; there is no project file):

```powershell
Get-Process DevLauncher -ErrorAction SilentlyContinue | Stop-Process -Force
$csc = "$env:WINDIR\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
& $csc /nologo /target:winexe /out:DevLauncher.exe /win32icon:DevLauncher.ico `
    /r:System.Windows.Forms.dll /r:System.Drawing.dll DevLauncher.cs
```

Run this from the launcher folder. A zero exit code and a fresh
`DevLauncher.exe` timestamp means it worked. (A pre-built exe ships in the zip,
but it's compiled for `C:\Dev` — always rebuild.)

## Step 4 — Check the runtime prerequisites

Tiles launch `wt.exe` (Windows Terminal) and run `claude`. Check both and tell
the user about anything missing:

```powershell
Get-Command wt.exe -ErrorAction SilentlyContinue      # optional — falls back to plain PowerShell window
Get-Command claude -ErrorAction SilentlyContinue      # required for tiles to actually start Claude
```

- No `wt.exe`: the launcher still works (plain PowerShell windows); suggest
  installing Windows Terminal from the Microsoft Store for the tabbed experience.
- No `claude`: tiles will open a terminal that errors. Point the user at
  `npm install -g @anthropic-ai/claude-code` (or their team's install method).

## Step 5 — Create the shortcuts

Create a Desktop shortcut and a Start Menu shortcut, both pointing at the exe
(substitute the real launcher folder path):

```powershell
$exe = "<launcher folder>\DevLauncher.exe"
$dir = "<launcher folder>"
$ws  = New-Object -ComObject WScript.Shell
foreach ($lnkPath in @(
    (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Dev Launcher.lnk'),
    (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Dev Launcher.lnk')
)) {
    $lnk = $ws.CreateShortcut($lnkPath)
    $lnk.TargetPath       = $exe
    $lnk.WorkingDirectory = $dir
    $lnk.IconLocation     = "$exe,0"
    $lnk.Save()
}
```

## Step 6 — Pinning (manual — do not script it)

Windows 11 (24H2+) blocks programmatic pinning to both the taskbar and Start
(`Access denied`). Don't attempt it — it's a known dead end. Instead, tell the
user to finish with one manual step:

> Right-click the **Dev Launcher** desktop shortcut (or the running app's
> taskbar icon) → **Pin to taskbar**. Same for Start: right-click → Pin to Start.

The window belongs to `DevLauncher.exe` itself, so the pin captures the right
app (not a PowerShell host).

## Step 7 — Verify

1. Start the exe (double-click or `Start-Process .\DevLauncher.exe`).
2. Confirm a tile appears for each subfolder of the chosen root, newest-modified
   first, plus a ➕ New Project tile.
3. Click a tile: a Windows Terminal tab should open in that project folder with
   `claude` starting. If it does, setup is done.

## After setup — customizing tiles (tell the user)

`apps.txt` next to the exe holds optional per-project overrides — display name
and the initial prompt Claude gets. One line per project:

```
Name | C:\Path\To\Folder | What Claude should do first (the initial prompt)
```

Folders without an entry still get a tile (folder name + a generic prompt).
Keep `|` out of the prompt text. Reopen the launcher to pick up edits. Each tile
also has a ✎ button for a one-off custom prompt and a ★ to pin it to the
favorites bar.
